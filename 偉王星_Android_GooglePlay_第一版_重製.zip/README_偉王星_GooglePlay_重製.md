# 偉王星 Android Google Play 第一版（重製）

App 名稱：偉王星
目前 App 會開啟你的線上網站：
https://super-butterfly-ed93.lion10i41112233.workers.dev/

applicationId：com.miniplay.app（尚未正式上架前仍可再決定）
versionCode：1
versionName：1.0

這是 Android 專案 ZIP，不是已簽署的 Google Play AAB。
